```
{
    "name": "TempleUniversity.ARCHIE"
}
```

